package com.crud.model;

public class Order {
    private int id;
    private Product product;

    public Order(int id, Product product) {
        this.id = id;
        this.product = product;
    }

    public int getId() {
        return id;
    }

    public Product getProduct() {
        return product;
    }

    @Override
    public String toString() {
        return "Order{" +
                "id=" + id +
                ", product=" + product.toString() +
                '}';
    }
}