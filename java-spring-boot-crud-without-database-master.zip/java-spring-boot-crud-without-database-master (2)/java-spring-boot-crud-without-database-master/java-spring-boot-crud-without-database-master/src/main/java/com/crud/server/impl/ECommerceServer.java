package com.crud.server.impl;
import com.crud.model.Order;
import com.crud.model.Product;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ECommerceServer {
    private static final int PORT = 8000;
    private List<Order> allOrders;
    private Map<Integer, Product> products;
    private Map<Integer, Integer> stock;

    public ECommerceServer() {
        allOrders = new ArrayList<>();
        products = new HashMap<>();
        stock = new HashMap<>();

        // Create mock Product data
        createMockProducts();
    }

    private void createMockProducts() {
        // Assuming Product ID starts from 1
        Product product1 = new Product(1, "Product 1", 10.99, 5);
        Product product2 = new Product(2, "Product 2", 5.99, 10);
        Product product3 = new Product(3, "Product 3", 8.49, 3);

        products.put(product1.getId(), product1);
        products.put(product2.getId(), product2);
        products.put(product3.getId(), product3);

        stock.put(product1.getId(), product1.getStockQuantity());
        stock.put(product2.getId(), product2.getStockQuantity());
        stock.put(product3.getId(), product3.getStockQuantity());
    }

    public void start() {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server started. Listening on port: " + PORT);
            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("New client connected: " + socket.getInetAddress().getHostAddress());
                handleClient(socket);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleClient(Socket socket) {
        try (DataInputStream inputStream = new DataInputStream(socket.getInputStream());
             DataOutputStream outputStream = new DataOutputStream(socket.getOutputStream())) {

            int messageType = inputStream.readShort();
            int payloadLength = inputStream.readInt();
            byte[] payloadData = new byte[payloadLength];
            inputStream.readFully(payloadData);

            String payload = new String(payloadData);
            String response;

            switch (messageType) {
                case 1: // Get All Orders
                    response = getAllOrders();
                    break;
                case 2: // Get Order Details
                    response = getOrderDetails(payload);
                    break;
                case 3: // Place an Order
                    response = placeOrder(payload);
                    break;
                default:
                    response = "Invalid message type.";
            }

            byte[] responseData = response.getBytes();
            outputStream.writeInt(responseData.length);
            outputStream.write(responseData);
            outputStream.flush();

            System.out.println("Response sent to client: " + socket.getInetAddress().getHostAddress());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String getAllOrders() {
        StringBuilder responseBuilder = new StringBuilder();
        for (Order order : allOrders) {
            responseBuilder.append(order.toString()).append("\n");
        }
        return responseBuilder.toString();
    }

    private String getOrderDetails(String orderId) {
        int id = Integer.parseInt(orderId);
        StringBuilder responseBuilder = new StringBuilder();
        for (Order order : allOrders) {
            if (order.getId() == id) {
                responseBuilder.append(order.toString());
                return responseBuilder.toString();
            }
        }
        return "Invalid order ID.";
    }

    private String placeOrder(String orderPayload) {
        int productId = Integer.parseInt(orderPayload);
        if (products.containsKey(productId)) {
            Product product = products.get(productId);
            int quantity = stock.get(productId);
            if (quantity > 0) {
                stock.put(productId, quantity - 1); // Decrease stock quantity

                Order order = new Order(allOrders.size() + 1, product);
                allOrders.add(order);

                return "Order placed successfully.";
            } else {
                return "Product out of stock.";
            }
        } else {
            return "Invalid product ID.";
        }
    }

    public static void main(String[] args) {
        ECommerceServer server = new ECommerceServer();
        server.start();
    }
}



